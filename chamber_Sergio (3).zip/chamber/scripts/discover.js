// Conditions
// * If the user has never visited our website, there are no cookies to retrieve.
// * if they have been to our website, then we have to retrieve cookies.

//Store data in local Storage//
let lastdate= localStorage.setItem("lastDate", d.toString());
let lastmonth= localStorage.setItem("lastMonth", m.toString());
let lastyear= localStorage.setItem("lastYear", y.toString());


localStorage.getItem("lastDate");
localStorage.getItem("lastMonth");
localStorage.getItem("lastYear");

If () {
    let lastdate= NULL;
    let lastmonth = NULL;
    let lastyear = NULL
    
}